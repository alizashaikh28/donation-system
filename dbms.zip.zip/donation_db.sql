CREATE DATABASE donation_db;
USE donation_db;

CREATE TABLE admin (
    admin_id  INT AUTO_INCREMENT PRIMARY KEY,
    username  VARCHAR(50),
    password  VARCHAR(50)
);

CREATE TABLE donor (
    donor_id    INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(100),
    phone       VARCHAR(15),
    address     TEXT,
    donor_type  VARCHAR(20),
    blood_group VARCHAR(5),
    organ_type  VARCHAR(50)
);

-- STEP 3: CAMPAIGN table (no foreign keys, so create before donation)
CREATE TABLE campaign (
    campaign_id   INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    type          VARCHAR(50),
    start_date    DATE,
    end_date      DATE,
    target_amount DOUBLE
);

-- STEP 4: BENEFICIARY table
CREATE TABLE beneficiary (
    beneficiary_id INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(100) NOT NULL,
    contact        VARCHAR(100),
    address        TEXT,
    type           VARCHAR(50)
);

-- STEP 5: DONATION table (depends on donor)
CREATE TABLE donation (
    donation_id   INT AUTO_INCREMENT PRIMARY KEY,
    donor_id      INT NOT NULL,
    donation_type VARCHAR(20),
    amount        DOUBLE DEFAULT 0,
    donation_date DATE,
    status        VARCHAR(50),
    FOREIGN KEY (donor_id) REFERENCES donor(donor_id)
);

-- STEP 6: PAYMENT table (depends on donation)
CREATE TABLE payment (
    payment_id      INT AUTO_INCREMENT PRIMARY KEY,
    donation_id     INT NOT NULL,
    payment_mode    VARCHAR(50),
    payment_date    DATE,
    status          VARCHAR(50),
    transaction_ref VARCHAR(100),
    FOREIGN KEY (donation_id) REFERENCES donation(donation_id)
);

-- STEP 7: RECEIPT table (depends on payment)
CREATE TABLE receipt (
    receipt_id   INT AUTO_INCREMENT PRIMARY KEY,
    payment_id   INT NOT NULL,
    receipt_date DATE,
    FOREIGN KEY (payment_id) REFERENCES payment(payment_id)
);

-- STEP 8: RELATION tables
CREATE TABLE donation_campaign (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    donation_id INT,
    campaign_id INT,
    FOREIGN KEY (donation_id) REFERENCES donation(donation_id),
    FOREIGN KEY (campaign_id) REFERENCES campaign(campaign_id)
);

CREATE TABLE receives (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    donation_id    INT,
    beneficiary_id INT,
    FOREIGN KEY (donation_id)    REFERENCES donation(donation_id),
    FOREIGN KEY (beneficiary_id) REFERENCES beneficiary(beneficiary_id)
);

-- STEP 9: Insert sample data so you can test immediately

INSERT INTO donor (name, email, phone, address, donor_type, blood_group) VALUES
('Rahul Sharma',   'rahul@gmail.com',   '9876543210', 'Mumbai, Maharashtra',  'Individual',   'B+'),
('Priya Patel',    'priya@gmail.com',   '9823456789', 'Pune, Maharashtra',    'Individual',   'A+'),
('Suresh Kumar',   'suresh@gmail.com',  '9812345678', 'Delhi',                'Organization', 'O+'),
('Anita Desai',    'anita@gmail.com',   '9801234567', 'Ahmedabad, Gujarat',   'Individual',   'AB+'),
('Vikram Singh',   'vikram@gmail.com',  '9798765432', 'Jaipur, Rajasthan',    'Individual',   'B-');

INSERT INTO campaign (name, type, start_date, end_date, target_amount) VALUES
('Blood for Life',     'Blood Drive',  '2024-01-01', '2024-03-31', 0),
('Feed the Needy',     'Food Drive',   '2024-02-01', '2024-04-30', 50000),
('Help Mumbai Flood',  'Fundraiser',   '2024-03-01', '2024-05-31', 200000);

INSERT INTO beneficiary (name, contact, address, type) VALUES
('City Hospital',       '022-12345678', 'Mumbai',       'Hospital'),
('Anath Ashram NGO',    '9876501234',   'Pune',         'NGO'),
('Govt Relief Fund',    '011-98765432', 'Delhi',        'Government');

INSERT INTO donation (donor_id, donation_type, amount, donation_date, status) VALUES
(1, 'Money',  5000,  '2024-01-15', 'Completed'),
(2, 'Blood',  0,     '2024-01-20', 'Completed'),
(3, 'Money',  25000, '2024-02-10', 'Completed'),
(4, 'Money',  1500,  '2024-02-18', 'Pending'),
(5, 'Money',  3000,  '2024-03-05', 'Completed');

INSERT INTO payment (donation_id, payment_mode, payment_date, status, transaction_ref) VALUES
(1, 'UPI',         '2024-01-15', 'Success', 'UPI123456789'),
(3, 'Net Banking', '2024-02-10', 'Success', 'NB987654321'),
(5, 'Cash',        '2024-03-05', 'Success', 'CASH001');

INSERT INTO receipt (payment_id, receipt_date) VALUES
(1, '2024-01-15'),
(2, '2024-02-10'),
(3, '2024-03-05');

SHOW TABLES;

SELECT * FROM donor;
SELECT * FROM donation;
SELECT * FROM payment;
SELECT * FROM receipt;
